import pytest
from app import create_app, db
from app.models.user import User

@pytest.fixture
def client():
    app = create_app()
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
            yield client
            db.session.remove()
            db.drop_all()

def test_register(client):
    response = client.post('/register', json={
        'email': 'test@example.com',
        'phone': '+1234567890',
        'password': 'password123',
        'name': 'Test User',
        'user_type': 'user'
    })
    assert response.status_code == 201
    assert b'User registered successfully' in response.data

def test_login(client):
    # First register a user
    client.post('/register', json={
        'email': 'test@example.com',
        'phone': '+1234567890',
        'password': 'password123',
        'name': 'Test User',
        'user_type': 'user'
    })
    
    # Then try to login
    response = client.post('/login', json={
        'email': 'test@example.com',
        'password': 'password123'
    })
    assert response.status_code == 200
    assert 'access_token' in response.get_json()