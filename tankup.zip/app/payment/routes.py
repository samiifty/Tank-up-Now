from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.models.payment import Payment, PromoCode
from app import db

bp = Blueprint('payment', __name__)

@bp.route('/payment/process', methods=['POST'])
@jwt_required()
def process_payment():
    data = request.get_json()
    
    payment = Payment(
        order_id=data['order_id'],
        amount=data['amount'],
        payment_method=data['payment_method']
    )
    
    # Process payment logic here (integrate with payment gateway)
    
    db.session.add(payment)
    db.session.commit()
    
    return jsonify({'message': 'Payment processed successfully'}), 200

@bp.route('/promo/apply', methods=['POST'])
@jwt_required()
def apply_promo():
    data = request.get_json()
    promo = PromoCode.query.filter_by(code=data['code'], is_active=True).first()
    
    if not promo:
        return jsonify({'error': 'Invalid promo code'}), 400
        
    discount = data['amount'] * (promo.discount_percent / 100)
    return jsonify({'discount': discount}), 200