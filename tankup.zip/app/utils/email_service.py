from flask_mail import Message
from app import mail
from flask import current_app

def send_confirmation_email(user_email, name):
    msg = Message('Welcome to Fuel Delivery Service',
                  sender=current_app.config['MAIL_USERNAME'],
                  recipients=[user_email])
    msg.body = f'Hello {name},\n\nWelcome to our Fuel Delivery Service!'
    mail.send(msg)

def send_order_confirmation(user_email, order_id):
    msg = Message('Order Confirmation',
                  sender=current_app.config['MAIL_USERNAME'],
                  recipients=[user_email])
    msg.body = f'Your order #{order_id} has been confirmed.'
    mail.send(msg)