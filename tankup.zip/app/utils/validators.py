from validate_email import validate_email
import phonenumbers

def validate_email_format(email):
    return validate_email(email)

def validate_phone_number(phone_number):
    try:
        parsed_number = phonenumbers.parse(phone_number, None)
        return phonenumbers.is_valid_number(parsed_number)
    except:
        return False

def validate_order_data(data):
    required_fields = ['fuel_type', 'quantity', 'delivery_location']
    return all(field in data for field in required_fields)

def validate_payment_data(data):
    required_fields = ['order_id', 'amount', 'payment_method']
    return all(field in data for field in required_fields)