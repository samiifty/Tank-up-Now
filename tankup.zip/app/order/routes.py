from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.models.order import Order
from app.models.payment import Payment
from app import db

bp = Blueprint('order', __name__)

@bp.route('/order/create', methods=['POST'])
@jwt_required()
def create_order():
    user_id = get_jwt_identity()
    data = request.get_json()
    
    order = Order(
        user_id=user_id,
        fuel_type=data['fuel_type'],
        quantity=data['quantity'],
        total_amount=data['total_amount'],
        delivery_location=data['delivery_location'],
        status='pending'
    )
    
    db.session.add(order)
    db.session.commit()
    
    return jsonify({'message': 'Order created successfully', 'order_id': order.id}), 201

@bp.route('/order/<int:order_id>/track', methods=['GET'])
@jwt_required()
def track_order(order_id):
    order = Order.query.get_or_404(order_id)
    tracking_info = {
        'status': order.status,
        'driver_location': order.driver.current_location if order.driver else None,
        'estimated_delivery_time': '30 minutes'  # This would be calculated based on distance
    }
    return jsonify(tracking_info)