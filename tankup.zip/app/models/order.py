from app import db
from datetime import datetime

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    driver_id = db.Column(db.Integer, db.ForeignKey('driver.id'))
    fuel_type = db.Column(db.String(20))
    quantity = db.Column(db.Float)
    total_amount = db.Column(db.Float)
    status = db.Column(db.String(20))  # pending, accepted, in_progress, completed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    delivery_location = db.Column(db.String(256))
    
    # Relationships
    payment = db.relationship('Payment', backref='order', lazy=True, uselist=False)
    tracking = db.relationship('OrderTracking', backref='order', lazy=True)