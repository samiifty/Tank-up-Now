from app import db

class Driver(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    vehicle_type = db.Column(db.String(50))
    vehicle_number = db.Column(db.String(20))
    license_number = db.Column(db.String(50))
    current_location = db.Column(db.String(256))
    is_available = db.Column(db.Boolean, default=True)
    
    # Relationships
    deliveries = db.relationship('Order', backref='driver', lazy=True)
    documents = db.relationship('DriverDocument', backref='driver', lazy=True)