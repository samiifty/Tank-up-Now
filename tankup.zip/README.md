# Fuel Delivery System

A Flask-based API for managing fuel delivery services.

## Setup Instructions

1. Create a virtual environment:
   ```bash
   python -m venv venv
   ```

2. Activate the virtual environment:
   - Windows:
     ```bash
     venv\Scripts\activate
     ```
   - Unix/MacOS:
     ```bash
     source venv/bin/activate
     ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Create .env file:
   Copy the .env.example file to .env and update the values with your configurations.

5. Initialize the database:
   ```bash
   flask db upgrade
   ```

6. Run the application:
   ```bash
   flask run
   ```

The application will be available at http://localhost:5000

## API Endpoints

### Authentication
- POST /register - Register new user
- POST /login - User login

### Orders
- POST /order/create - Create new order
- GET /order/{order_id}/track - Track order status

### Payments
- POST /payment/process - Process payment
- POST /promo/apply - Apply promo code

## Testing
Run tests using:
```bash
python -m pytest
```